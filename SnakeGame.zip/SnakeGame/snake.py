from turtle import Turtle
STARTING_X_POSITIONS = [0, -20, -40]
MOVE_DISTANCE = 20
UP = 90
DOWN = 270
LEFT = 180
RIGHT = 0


class Snake:

    def __init__(self):
        self.snake = []
        self.create_snake()
        self.head = self.snake[0]

    def create_snake(self):
        for position in STARTING_X_POSITIONS:
            self.add_body_part(position)

    def add_body_part(self, position):
        body_part = Turtle(shape="square")
        body_part.color("white")
        body_part.penup()
        body_part.goto(position, 0)
        self.snake.append(body_part)

    def extend(self):
        self.add_body_part(self.snake[-1].xcor())

    def turn_left(self):
        if self.head.heading() != RIGHT:
            self.head.setheading(LEFT)

    def turn_right(self):
        if self.head.heading() != LEFT:
            self.head.setheading(RIGHT)

    def turn_up(self):
        if self.head.heading() != DOWN:
            self.head.setheading(UP)

    def turn_down(self):
        if self.head.heading() != UP:
            self.head.setheading(DOWN)

    def did_i_die(self):

        # check if I hit a wall on any side
        if abs(self.snake[0].xcor()) > 240 or abs(self.snake[0].ycor()) > 240:
            return True
        else:
            # check if I hit my own body at any point
            for x in range(1, len(self.snake)):
                if self.head.position() == self.snake[x].position():
                    return True
            return False

    def move(self):
        # move each segment to the position
        # of the next segment in the body
        for segment in range(len(self.snake) - 1, 0, -1):
            x_pos = self.snake[segment - 1].xcor()
            y_pos = self.snake[segment - 1].ycor()
            self.snake[segment].goto(x_pos, y_pos)
            # dead = did_i_die()
        self.head.forward(MOVE_DISTANCE)
