from turtle import Screen
import time
from snake import Snake
from food import Food
from scoreboard import Scoreboard

# initialize screen object, snake object, food object, and scoreboard object
screen = Screen()
screen.bgcolor("black")
screen.setup(width=500, height=500)
screen.title("My Snake Game")
screen.tracer(0)
snake = Snake()
food = Food()
scoreboard = Scoreboard()

screen.listen()
screen.onkey(key="Up", fun=snake.turn_up)
screen.onkey(key="Down", fun=snake.turn_down)
screen.onkey(key="Left", fun=snake.turn_left)
screen.onkey(key="Right", fun=snake.turn_right)

dead = False
while not dead:
    screen.update()
    time.sleep(0.1)

    snake.move()

    # detect a collision
    if snake.head.distance(food) < 15:
        food.refresh()
        snake.extend()
        scoreboard.update_score()

    dead = snake.did_i_die()
    if dead:
        scoreboard.game_over()

screen.exitonclick()
